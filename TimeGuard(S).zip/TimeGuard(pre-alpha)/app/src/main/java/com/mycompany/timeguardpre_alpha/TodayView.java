package com.mycompany.timeguardpre_alpha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class TodayView extends AppCompatActivity {

    Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_today_view);

        addListenerOnButton();
    }

    public void addListenerOnButton()
    {

        button1 = (Button) findViewById(R.id.toToday);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                continueToToday(v);
            }
        });


    }

    public void continueToToday (View view)
    {
        Intent intent = new Intent(this, TodayViewReal.class);
        startActivity(intent);
    }

}
