package com.mycompany.timeguardpre_alpha;


import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Handler;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;



public class TodayViewReal extends AppCompatActivity {

    private final static String filename = "schedule.txt";
    String objective, amPm = "am";
    int hours, minutes, seconds, theDate, eventDate, currentTime, objEndTime;

    TextView event, time, duration, comment;
    TextView field;
    Handler mHandler;
    ImageView frames;
    boolean activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_today_view_real);

        mHandler = new Handler();
        mHandler.post(mUpdate);

    }

    private Runnable mUpdate = new Runnable() {
        public void run() {
            field = (TextView) findViewById(R.id.display);
            frames = (ImageView) findViewById(R.id.displayFrames);


            Calendar test = Calendar.getInstance();
            String hours1 = "", minutes1 = "", seconds1 = "";
            hours = test.get(test.HOUR_OF_DAY);
            minutes = test.get(test.MINUTE);
            seconds = test.get(test.SECOND);

            theDate = (test.get(test.MONTH) + 1) * 1000000 +
                    test.get(test.DAY_OF_MONTH) * 10000 +
                    test.get(test.YEAR);

            if (hours > 12) {
                hours = hours - 12;
                amPm = "pm";
            }

            if (hours == 0) {
                hours += 12;
                amPm = "am";
            }

            if (hours < 10)
                hours1 = "0" + hours;
            else
                hours1 = Integer.toString(hours);

            if (minutes < 10)
                minutes1 = "0" + minutes;
            else
                minutes1 = Integer.toString(minutes);

            if (seconds < 10)
                seconds1 = "0" + seconds;
            else
                seconds1 = Integer.toString(seconds);

            field.setText(hours1 + ":" + minutes1 + ":" + seconds1 + " " + amPm);

            currentTime = (hours * 100) + minutes;
            if (amPm.equals("pm"))
                currentTime = currentTime + 1200;

            fileStuff();
            formatIt();

            mHandler.postDelayed(this, 500);
        }
    };


    public void fileStuff() {

        try {
            File file = new File(getFilesDir(), filename);
            InputStream is = new
                    BufferedInputStream(new FileInputStream(file));
            BufferedReader br = new
                    BufferedReader(new InputStreamReader(is));
            String input;
            objective = "";
            while ((input = br.readLine()) != null)
                objective += input;
            br.close();
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void formatIt() {
        int j = 0;
        String[] stuff;

        stuff = new String[5];
        // 0 - Event
        // 1 - Date
        // 2 - start time (24 hour)
        // 3 - End time (24 hours)
        // 4 - comment


        int objTime = 0, objHour = 0, objMint = 0, objEndHour = 0, objEndMint = 0;
        String objAmPm = "am", objEndAmPm = "am", objMint1 = "", objEndMint1 = "";
        Boolean write = true;

        int i = 0;

        eventDate = 0;

        while (eventDate != theDate ||
                currentTime > objEndTime) {
            objAmPm = "am";
            objEndAmPm = "am";


            j = 0;
            stuff[0] = "";
            stuff[1] = "";
            stuff[2] = "";
            stuff[3] = "";
            stuff[4] = "";

            if (objective.charAt(i) == '>') {
                i++;
                while (j < 5) {
                    while (objective.charAt(i) != '$') {
                        stuff[j] = stuff[j] + objective.charAt(i);
                        i++;
                    }
                    i++;
                    j++;
                }
            } else
                i++;


            objTime = Integer.parseInt(stuff[2]);
            objHour = objTime / 100;
            objMint = objTime % 100;
            if (objHour >= 12) {
                objHour = objHour - 12;
                objAmPm = "pm";
            }
            if (objHour == 12)
                objAmPm = "am";
            if (objHour == 0)
                objHour += 12;
            if (objMint < 10)
                objMint1 = "0" + Integer.toString(objMint);
            else
                objMint1 = Integer.toString(objMint);

            objEndTime = Integer.parseInt(stuff[3]);
            objEndHour = objEndTime / 100;
            objEndMint = objEndTime % 100;
            if (objEndHour >= 12) {
                objEndHour = objEndHour - 12;
                objEndAmPm = "pm";
            }
            if (objEndHour == 12)
                objEndAmPm = "am";
            if (objEndHour == 0)
                objEndHour += 12;
            if (objEndMint < 10)
                objEndMint1 = "0" + Integer.toString(objEndMint);
            else
                objEndMint1 = Integer.toString(objEndMint);

            eventDate = Integer.parseInt(stuff[1]);

            if (i == objective.length()) {
                write = false;
                break;
            }
        }

        if (write) {
            if (!stuff[3].equals(stuff[2])) {
                event = (TextView) findViewById(R.id.event);
                event.setText(stuff[0]);

                time = (TextView) findViewById(R.id.time);
                time.setText("Starts at " + objHour + ":" + objMint1 + " " + objAmPm);

                duration = (TextView) findViewById(R.id.duration);
                duration.setText("Ends at " + objEndHour + ":" + objEndMint1 + " " + objEndAmPm);

                comment = (TextView) findViewById(R.id.comment);
                comment.setText(stuff[4]);
            } else {
                event = (TextView) findViewById(R.id.event);
                event.setText(stuff[0]);

                time = (TextView) findViewById(R.id.time);
                time.setText("At " + objHour + ":" + objMint1 + " " + objAmPm);

                duration = (TextView) findViewById(R.id.duration);
                duration.setText("");

                comment = (TextView) findViewById(R.id.comment);
                comment.setText(stuff[4]);
            }
        }
    }
}
