package com.mycompany.timeguardpre_alpha;

import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class AheadViewReal extends AppCompatActivity {

    String objective, filename = "schedule.txt", todaysObjectives;
    int differ, theDate;

    TextView date, activities;

    Button increase, decrease;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ahead_view_real2);

        differ = 0;

        fileStuff();
        retrieve();

        influenceData();
    }

    public void fileStuff()
    {
        try {
            File file = new File(getFilesDir(), filename);
            InputStream is = new
                    BufferedInputStream(new FileInputStream(file));
            BufferedReader br = new
                    BufferedReader(new InputStreamReader(is));
            String input;
            objective = "";
            while ((input = br.readLine()) != null)
                objective += input;
            br.close();
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void retrieve()
    {
        int j = 0, i = 0;
        String[] stuff;


        todaysObjectives = "";

        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, + differ);
        SimpleDateFormat df = new SimpleDateFormat("MMddyyyy");
        String formattedDate = df.format(c.getTime());


        theDate = (c.get(c.MONTH) + 1) * 1000000+
                c.get(c.DAY_OF_MONTH) * 10000+
                c.get(c.YEAR);

        date = (TextView) findViewById(R.id.day);
        date.setText(c.get(c.MONTH) + 1 + "/" +
                     c.get(c.DAY_OF_MONTH) + "/" +
                     c.get(c.YEAR));


        stuff = new String[5];
        // 0 - Event
        // 1 - Date
        // 2 - start time (24 hour)
        // 3 - end time (24 hour)
        // 4 - comment



        while(i < objective.length())
        {
            j = 0;
            stuff[0] = "";
            stuff[1] = "";
            stuff[2] = "";
            stuff[3] = "";
            stuff[4] = "";

            int objTime = 0, objHour = 0, objMint = 0, objEndHour = 0, objEndMint = 0, objEndTime = 0;
            String objAmPm = "am", objEndAmPm = "am", objMint1 = "", objEndMint1 = "";

            if(objective.charAt(i) == '>')
            {
                i++;
                while(j < 5)
                {
                    while(objective.charAt(i) != '$')
                    {
                        stuff[j] = stuff[j] + objective.charAt(i);
                        i++;
                    }
                    i++;
                    j++;
                }

            }
            else
                i++;


            objTime = Integer.parseInt(stuff[2]);
            objHour = objTime / 100;
            objMint = objTime % 100;

            if (objHour >= 12)
            {objHour = objHour - 12; objAmPm = "pm";}
            if (objHour == 12)
                objAmPm = "am";
            if (objHour == 0)
                objHour += 12;
            if (objMint < 10)
                objMint1 = "0" + Integer.toString(objMint);
            else
                objMint1 = Integer.toString(objMint);

            objEndTime = Integer.parseInt(stuff[3]);
            objEndHour = objEndTime / 100;
            objEndMint = objEndTime % 100;
            if (objEndHour >= 12)
            {objEndHour = objEndHour - 12; objEndAmPm = "pm";}
            if (objEndHour == 12)
                objEndAmPm = "am";
            if (objEndHour == 0)
                objEndHour += 12;
            if (objEndMint < 10)
                objEndMint1 = "0" + Integer.toString(objEndMint);
            else
                objEndMint1 = Integer.toString(objEndMint);

            if (theDate == Integer.parseInt(stuff[1]))
            {
                if (!stuff[3].equals(stuff[2]))
                {
                    todaysObjectives = todaysObjectives +
                            (stuff[0] + "\n     From " +
                            objHour + ":" + objMint1 +
                            " " + objAmPm + " to " + objEndHour +
                            ":" + objEndMint1 + " " + objEndAmPm + "\n\n");
                }
                else
                {
                    todaysObjectives = todaysObjectives +
                            (stuff[0] + "\n     At " +
                             objHour + ":" + objMint1 +
                             " " + objAmPm + "\n\n");
                }
            }

            if(i == objective.length())
                break;
        }

        activities = (TextView) findViewById(R.id.activities);
        activities.setText(todaysObjectives);
        //activities.setText(formattedDate);
    }

    public void influenceData()
    {
        increase = (Button) findViewById(R.id.forward);
        decrease = (Button) findViewById(R.id.back);

        increase.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View arg0)
            {
                differ = differ + 1;
                retrieve();
            }
        });

        decrease.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View arg0)
            {
                differ = differ - 1;
                retrieve();
            }
        });
    }
}
