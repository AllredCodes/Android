package com.mycompany.timeguardpre_alpha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainMenu extends AppCompatActivity {

    ImageButton button1, button2, button3, button4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        addListenerOnButton();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void addListenerOnButton()
    {
        button1 = (ImageButton) findViewById(R.id.todayBtn);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                goToTodayView(v);
            }
        });

        button2 = (ImageButton) findViewById(R.id.aheadBtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                goToAheadView(v);
            }
        });

        button3 = (ImageButton) findViewById(R.id.buildBtn);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                goToBuildView(v);
            }
        });

        button4 = (ImageButton) findViewById(R.id.stuffBtn);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                goToStuffView(v);
            }
        });    }

    public void goToTodayView (View view)
    {
        Intent intent = new Intent(this, TodayView.class);
        startActivity(intent);
    }

    public void goToAheadView (View view)
    {
        Intent intent = new Intent(this, AheadView.class);
        startActivity(intent);
    }

    public void goToBuildView (View view)
    {
        Intent intent = new Intent(this, BuildView.class);
        startActivity(intent);
    }

    public void goToStuffView (View view)
    {
        Intent intent = new Intent(this, StuffView.class);
        startActivity(intent);
    }

}
