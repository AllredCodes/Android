package com.mycompany.timeguardpre_alpha;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class BuildViewReal extends AppCompatActivity {

    Spinner NameSpinner;
    EditText NameCustom, edtComment;
    TextView testing, theDate, timeDisplay;
    Button finish, nextDay, prevDay, startTimePick, endTimePick;

    String preName, customName, activeName, activeComment, activeDate,
            objective, filename = "schedule.txt", newObjective, displayDate;
    int    dateOffSet, startHour, startMinute, endHour, endMinute, activeStart, activeEnd;
    Boolean confirm;

    static final int START_ID = 0, END_ID = 1;
    private final static String WRITE_THIS = "schedule.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_build_view_real);
        activeEnd = 9999;
        newObjective = "";


        listenUp();
    }

    public void fileStuff() // load
    {
        try {
            File file = new File(getFilesDir(), filename);
            InputStream is = new
                    BufferedInputStream(new FileInputStream(file));
            BufferedReader br = new
                    BufferedReader(new InputStreamReader(is));
            String input;
            objective = "";
            while ((input = br.readLine()) != null)
                objective += input;
            br.close();
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void listenUp()
    {
        // Activity Name Section

        preName = "";
        customName = "";

        NameCustom = (EditText) findViewById(R.id.CustomName);

        NameSpinner = (Spinner) findViewById(R.id.nameSpinner);
        String[] items = new String[]
        {
                "Work",
                "Study",
                "Exercise",
                "Socialize",
                "Relax",
                "Hobby"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, items);
        NameSpinner.setAdapter(adapter);


        // Activity Date Section

        showDate();

        nextDay = (Button) findViewById(R.id.nextDate);
        nextDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                dateOffSet += 1;
                showDate();
            }
        });

        prevDay = (Button) findViewById(R.id.previousDate);
        prevDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if (dateOffSet > 0)
                   dateOffSet -= 1;
                showDate();
            }
        });


        // Activity Duration Section


        DatePickerDialog.OnDateSetListener startActivity, endActivity;

        startTimePick = (Button) findViewById(R.id.startTime);
        startTimePick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(START_ID);
                updateTime();
            }
        });

        endTimePick = (Button) findViewById(R.id.endTime);
        endTimePick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(END_ID);
                updateTime();
            }
        });


        // Activity Comment Section


            // Eh.. Eheheheh.. ^_^'


        // Confirmation Section

        finish = (Button) findViewById(R.id.confirm);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fileStuff();

                preName = NameSpinner.getSelectedItem().toString();
                customName = NameCustom.getText().toString();

                if (customName.equals(""))
                    activeName = preName;
                else
                    activeName = customName;

                edtComment = (EditText) findViewById(R.id.enterComment);
                activeComment = edtComment.getText().toString();

                if (confirm == null)
                    confirm = false;

                confirmEntry();
            }
        });



    }


    public void confirmEntry()
    {
        String startAmPm = "am", endAmPm = "am", startMin = "", endMin = "";
        int disStartHour = startHour, disEndHour = endHour;

        if(startHour >= 12)
        {
            disStartHour -= 12;
            startAmPm = "pm";
        }
        if(disStartHour == 12)
            startAmPm = "am";
        if(disStartHour == 0)
            disStartHour += 12;
        if(startMinute < 10)
            startMin = "0" + Integer.toString(startMinute);
        else
            startMin = Integer.toString(startMinute);


        if(endHour >= 12)
        {
            disEndHour -= 12;
            endAmPm = "pm";
        }
        if(disEndHour == 12)
            endAmPm = "am";
        if(disEndHour == 0)
            disEndHour += 12;
        if(endMinute < 10)
            endMin = "0" + Integer.toString(endMinute);
        else
            endMin = Integer.toString(endMinute);


        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Confirm Activity")
                .setMessage("The following activity will be added;\n\n" +
                            "Activity name\n          " + activeName +
                          "\nDate\n          " + displayDate +
                          "\nStart and End\n          " + disStartHour + ":" + startMin + " " + startAmPm
                            + " to " + disEndHour + ":" + endMin + " " + endAmPm +
                          "\nComment\n          " + activeComment + "\n\n\n\n\n")
                .setPositiveButton("Yup, add it", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        becomesTrue();
                    }

                })
                .setNegativeButton("Then again..", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        becomesFalse();
                    }
                })
                .show();


    }

    public void becomesTrue()
    {
        confirm = true;

        newObjective = objective + ">" +
                activeName + "$" +
                activeDate + "$" +
                activeStart + "$" +
                activeEnd + "$" +
                activeComment + "$" +
                ">TGHG$99999999$9999$9999$$";

        addNewObjective();
    }

    public void becomesFalse()
    {
        confirm = false;
    }

    public void showDate()
    {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, + dateOffSet);
        SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");

        displayDate = df.format(c.getTime());

        SimpleDateFormat df1 = new SimpleDateFormat("MMddyyyy");

        activeDate = df1.format(c.getTime());

        theDate = (TextView) findViewById(R.id.activityDate);
        theDate.setText(displayDate);
    }

    public void updateTime()
    {
        String startAmPm = "am", endAmPm = "am", startMin = "", endMin = "";
        int disStartHour = startHour, disEndHour = endHour;
        Boolean write = true;

        if(startHour >= 12)
        {
            disStartHour -= 12;
            startAmPm = "pm";
        }
        if(disStartHour == 12)
            startAmPm = "am";
        if(disStartHour == 0)
            disStartHour += 12;
        if(startMinute < 10)
            startMin = "0" + Integer.toString(startMinute);
        else
            startMin = Integer.toString(startMinute);


        if(endHour >= 12)
        {
            disEndHour -= 12;
            endAmPm = "pm";
        }
        if(disEndHour == 12)
            endAmPm = "am";
        if(disEndHour == 0)
            disEndHour += 12;
        if(endMinute < 10)
            endMin = "0" + Integer.toString(endMinute);
        else
            endMin = Integer.toString(endMinute);


        if (activeEnd < activeStart)
            write = false;

        if (write == true){
        timeDisplay = (TextView) findViewById(R.id.timeDisplay);
        timeDisplay.setText(disStartHour + ":" + startMin + " " + startAmPm +
                            "   -   " + disEndHour + ":" + endMin + " " + endAmPm);}
    }

    public void addNewObjective()
    {
        try{
            File file = new File(getFilesDir(), filename);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(newObjective.getBytes());
            fos.flush();
            fos.close();

            Toast.makeText(this, "New Activity Recorded.", Toast.LENGTH_LONG).show();

        }
        catch (IOException e)
        {
            e.printStackTrace();
            Toast.makeText(this, "Failed to record activity.", Toast.LENGTH_LONG).show();
        }
    }







    @Override
    protected Dialog onCreateDialog(int id)
    {
        if (id == START_ID)
            return new TimePickerDialog(BuildViewReal.this, startTimePickerListener, startHour, startMinute, false);

        if (id == END_ID)
            return new TimePickerDialog(BuildViewReal.this, endTimePickerListener, endHour, endMinute, false);

        return null;
    }

    protected TimePickerDialog.OnTimeSetListener startTimePickerListener =
            new TimePickerDialog.OnTimeSetListener()
            {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute)
                {
                    startHour = hourOfDay;
                    startMinute = minute;

                    activeStart = (startHour * 100) + startMinute;
                    updateTime();
                }
            };

    protected TimePickerDialog.OnTimeSetListener endTimePickerListener =
            new TimePickerDialog.OnTimeSetListener()
            {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute)
                {
                    endHour = hourOfDay;
                    endMinute = minute;

                    activeEnd = (endHour * 100) + endMinute;
                    updateTime();
                }
            };
}


