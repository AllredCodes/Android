package com.mycompany.timeguardpre_alpha;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class StuffView extends AppCompatActivity {

    Button whipClean;
    String nothing, filename = "schedule.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stuff_view);
        nothing = "";

        clearSchedule();
    }

    public void clearSchedule()
    {
        whipClean = (Button) findViewById(R.id.clear);
        whipClean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    File file = new File(getFilesDir(), filename);
                    FileOutputStream fos = new FileOutputStream(file);
                    fos.write(nothing.getBytes());
                    fos.flush();
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
    }
}
