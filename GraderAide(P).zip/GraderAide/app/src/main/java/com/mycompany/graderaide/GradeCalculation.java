package com.mycompany.graderaide;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class GradeCalculation extends AppCompatActivity {

    Button button1;
    EditText total, correct, wrong;
    TextView grade;

    float correctQuestions = 0, finalGrade, totalQuestions = 0, wrongQuestions = 0;
    String newStuff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade_calculation);

        buttonHasBeenPressed();
    }

    public void buttonHasBeenPressed()
    {


        button1 = (Button) findViewById(R.id.calc);

        total = (EditText) findViewById(R.id.numQ);
        correct = (EditText) findViewById(R.id.numC);
        wrong = (EditText) findViewById(R.id.numW);

        grade = (TextView) findViewById(R.id.grade);

        button1.setOnClickListener(new View.OnClickListener()
          {
            @Override
            public void onClick(View v)
            {
                //run the numbers
                newStuff = total.getText().toString();
                totalQuestions = Integer.parseInt(newStuff);

                if (!TextUtils.isEmpty(correct.getText().toString())) {
                    newStuff = correct.getText().toString();
                    correctQuestions = Integer.parseInt(newStuff);

                    finalGrade = (100 / totalQuestions) * correctQuestions;
                }

                else if (!TextUtils.isEmpty(wrong.getText().toString()))
                {
                    newStuff = wrong.getText().toString();
                    wrongQuestions = Integer.parseInt(newStuff);

                    finalGrade = (100 / totalQuestions) * (totalQuestions - wrongQuestions);
                }

                else
                {// Nothing =/
                }

                grade.setText("GRADE\n" + String.format("%.2f", finalGrade));
            }
          }
        );



    }
}
