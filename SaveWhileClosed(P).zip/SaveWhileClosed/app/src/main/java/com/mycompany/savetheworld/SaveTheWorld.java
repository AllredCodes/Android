package com.mycompany.savetheworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class SaveTheWorld extends AppCompatActivity {

    Button save, load;
    EditText readSave;
    TextView writeSave;

    private String filename = "myapp.txt";
    private String loadedContents, fieldContents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_the_world);
        loadedContents = "";


        allTheWork();
    }

    public void allTheWork()
    {
        save = (Button) findViewById(R.id.saveButton);
        load = (Button) findViewById(R.id.loadButton);

        readSave = (EditText) findViewById(R.id.editSave);

        writeSave = (TextView) findViewById(R.id.loadField);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fieldContents = readSave.getText().toString();
                saveContents();
            }
        });

        load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadContents();

                writeSave.setText(loadedContents);
            }

        });





    }




    public void saveContents()
    {
        try {
            File file = new File(getFilesDir(), filename);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(fieldContents.getBytes());
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadContents()
    {
        try {
            File file = new File(getFilesDir(), filename);
            InputStream is = new
                    BufferedInputStream(new FileInputStream(file));
            BufferedReader br = new
                    BufferedReader(new InputStreamReader(is));
            String input;
            loadedContents = "";
            while ((input = br.readLine()) != null)
                loadedContents += input;
            br.close();
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
