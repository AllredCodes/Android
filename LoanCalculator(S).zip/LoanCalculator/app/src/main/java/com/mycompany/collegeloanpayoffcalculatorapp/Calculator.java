package com.mycompany.collegeloanpayoffcalculatorapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.DecimalFormat;

public class Calculator extends AppCompatActivity {

    Spinner yearSelect;
    Button doMath;
    EditText loanAmount, growthAmount;
    TextView finalValues;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculator);

        yearSelect = (Spinner) findViewById(R.id.yearsSpinner);
        Integer[] years = new Integer[]
        {
            5,
            10,
            15,
            20,
            25,
            30
        };
        ArrayAdapter<Integer> adapter = new ArrayAdapter<Integer>(this,
                android.R.layout.simple_spinner_dropdown_item, years);
        yearSelect.setAdapter(adapter);

        loanAmount = (EditText) findViewById(R.id.editAmount);
        growthAmount = (EditText) findViewById(R.id.editGrowth);
        finalValues = (TextView) findViewById(R.id.finalValues);

        doMath = (Button) findViewById(R.id.doMath);
        doMath.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                justDoTheMath();
            }
        });
    }

    void justDoTheMath()
    {
        double finalAmount = 0, monthlyAmount = 0, yearsSelected = 0, loanAmountLocal = 0;
        double growthPercent = 0;
        double tempValue1 = 0, tempValue2 = 0;
        String retrieveStringValues, writeFinal, writeMonthly;

        retrieveStringValues = yearSelect.getSelectedItem().toString();
        yearsSelected = Integer.parseInt(retrieveStringValues);

        retrieveStringValues = growthAmount.getText().toString();
        growthPercent = Integer.parseInt(retrieveStringValues);
        growthPercent = growthPercent/100;

        retrieveStringValues = loanAmount.getText().toString();
        loanAmountLocal = Integer.parseInt(retrieveStringValues);

        tempValue1 = loanAmountLocal * (yearsSelected * growthPercent);
        finalAmount = loanAmountLocal + tempValue1;

        monthlyAmount = finalAmount / (yearsSelected * 12);

        writeFinal = String.format("%.2f",finalAmount);
        writeMonthly = String.format("%.2f",monthlyAmount);

        finalValues.setText("$" + writeFinal + "\n\n" + "$" + writeMonthly);
    }

}
