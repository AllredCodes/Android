package com.mycompany.roadsignquiz;

import java.util.Random;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class RoadQuiz extends AppCompatActivity {

    Button confirmAnswer;
    Spinner signSelect;
    ImageView signDisply;

    int currentImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_road_quiz);

        signDisply = (ImageView) findViewById(R.id.signView);
        signSelect = (Spinner) findViewById(R.id.signNameSpinner);
        confirmAnswer = (Button) findViewById(R.id.confirmButton);

        mainFunction();
    }

    void mainFunction()
    {
        String[] signNames = new String[]
                {
                        "No left turn",
                        "No parking",
                        "Numbered route",
                        "Signal ahead",
                        "Slippery when wet",
                        "Stay right",
                        "Stop",
                        "Turn",
                        "Yield"
                };

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, signNames);
        signSelect.setAdapter(adapter);

        Random rng = new Random();
        currentImage = rng.nextInt(9);

        assignImage();

        confirmAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String answer = signSelect.getSelectedItem().toString();

                if ((answer == "No left turn" && currentImage == 0) ||
                        (answer == "No parking" && currentImage == 1) ||
                        (answer == "Numbered route" && currentImage == 2) ||
                        (answer == "Signal ahead" && currentImage == 3) ||
                        (answer == "Slippery when wet" && currentImage == 4) ||
                        (answer == "Stay right" && currentImage == 5) ||
                        (answer == "Stop" && currentImage == 6) ||
                        (answer == "Turn" && currentImage == 7) ||
                        (answer == "Yield" && currentImage == 8)) {
                    Toast.makeText(RoadQuiz.this, "Correct!", Toast.LENGTH_LONG).show();
                    mainFunction();
                } else {
                    Toast.makeText(RoadQuiz.this, "Wrong! Try again!", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    void assignImage()
    {
        if(currentImage == 0)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.no_left_turn));

        else if(currentImage == 1)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.no_parking));

        else if(currentImage == 2)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.numbered_route));

        else if(currentImage == 3)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.signal_ahead));

        else if(currentImage == 4)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.slippery_when_wet));

        else if(currentImage == 5)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.stay_right));

        else if(currentImage == 6)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.stop));

        else if(currentImage == 7)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.turn));

        else if(currentImage == 8)
            signDisply.setImageDrawable(getResources().getDrawable(R.drawable.yield));
    }


}
