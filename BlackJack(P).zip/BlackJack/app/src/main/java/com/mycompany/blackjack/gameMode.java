package com.mycompany.blackjack;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;


public class gameMode extends AppCompatActivity {

    Button button1, button2;
    ImageView player1, player2, player3, player4, player5, player6,
                dealer1, dealer2, dealer3, dealer4, dealer5, dealer6;
    TextView eventLog, score, currentPlayer, currentDealer;

    boolean runningGame, standing, playerAce, dealerAce;
    int currentPValue, currentDValue, currentScore,
        currentPCard, currentDCard, dealerShowValue;

    int[] playerCards = new int[6];  // Card number will be between 1 and 52
    int[] dealerCards = new int[6];
    int[] cardsValues = new int[12];
    int[] theDeck = new int[52];
    ImageView[] cardsDisplay = new ImageView[12];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_mode);

        button1 = (Button) findViewById(R.id.Button1);
        button2 = (Button) findViewById(R.id.Button2);

        player1 = (ImageView) findViewById(R.id.Pcard1);
        player2 = (ImageView) findViewById(R.id.Pcard2);
        player3 = (ImageView) findViewById(R.id.Pcard3);
        player4 = (ImageView) findViewById(R.id.Pcard4);
        player5 = (ImageView) findViewById(R.id.Pcard5);
        player6 = (ImageView) findViewById(R.id.Pcard6);

        dealer1 = (ImageView) findViewById(R.id.Dcard1);
        dealer2 = (ImageView) findViewById(R.id.Dcard2);
        dealer3 = (ImageView) findViewById(R.id.Dcard3);
        dealer4 = (ImageView) findViewById(R.id.Dcard4);
        dealer5 = (ImageView) findViewById(R.id.Dcard5);
        dealer6 = (ImageView) findViewById(R.id.Dcard6);

        eventLog = (TextView) findViewById(R.id.EventView);
        score = (TextView) findViewById(R.id.ScoreView);
        currentPlayer = (TextView) findViewById(R.id.CurrentPView);
        currentDealer = (TextView) findViewById(R.id.CurrentDView);

        cardsDisplay[0] = player1;
        cardsDisplay[1] = player2;
        cardsDisplay[2] = player3;
        cardsDisplay[3] = player4;
        cardsDisplay[4] = player5;
        cardsDisplay[5] = player6;

        cardsDisplay[6] = dealer1;
        cardsDisplay[7] = dealer2;
        cardsDisplay[8] = dealer3;
        cardsDisplay[9] = dealer4;
        cardsDisplay[10]= dealer5;
        cardsDisplay[11]= dealer6;

        mainFunction();
    }

    void mainFunction()
    {
        boolean runningGame = false;

        gameUpdate();
        cardVisualUpdate();

    }

    void gameUpdate()
    {
        if (runningGame)
        {
            button1.setText("Hit me!");
            button2.setEnabled(true);
            button2.setText("Stand!");

            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentPValue = 0;
                    if(currentPCard < 6)
                        dealNewCard(1);
                    checkGame();
                    cardVisualUpdate();
                }
            });

            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    currentPValue = 0;
                    standing = true;
                    dealersTurn();
                }
            });
        }

        else
        {
            button1.setText("Deal Hand");
            button2.setEnabled(false);

            button1.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View v)
                {
                    newGame();
                    checkGame();
                    cardVisualUpdate();
                }
            });
        }
    }

    void newGame()
    {
        runningGame = true;
        standing =false;

        eventLog.setText("");

        for (int i = 0; i < 52; i++)
            theDeck[i] = 1;

        currentPValue = 0;
        currentDValue = 0;

        currentPCard = 0;
        currentDCard = 0;

        playerAce = false;
        dealerAce = false;

        playerCards[0] = 0; playerCards[1] = 0; playerCards[2] = 0;     // Card number will be between 1 and 52
        playerCards[3] = 0; playerCards[4] = 0; playerCards[5] = 0;     // 1 - 13 Spades, 14 - 26 Hearts,
        dealerCards[0] = 0; dealerCards[1] = 0; dealerCards[2] = 0;     // 27 - 39 Clubs, 40 - 52 Diamonds
        dealerCards[3] = 0; dealerCards[4] = 0; dealerCards[5] = 0;

        cardVisualUpdate();

        dealNewCard(1);
        dealNewCard(1);

        dealNewCard(0);
        dealNewCard(0);

        dealerShowValue = cardMath(dealerCards[0], 0);

        cardVisualUpdate();
        gameUpdate();
    }

    void checkGame()
    {


        for (int i = 0; i < currentPCard; i++)
        {
            currentPValue += cardMath(playerCards[i], 1);
        }

        if (playerAce && currentPValue < 12)
            currentPValue += 10;

        currentDValue = 0;

        for (int i = 0; i < currentDCard; i++)
        {
            currentDValue += cardMath(dealerCards[i], 0);
        }

        if (dealerAce && currentDValue < 12)
            currentDValue += 10;

        if (currentPValue > 21)
        {
            eventLog.setText("You're over! Bust!");
            currentScore--;
            score.setText("SCORE: " + currentScore);
            runningGame = false;
            cardVisualUpdate();
            gameUpdate();
        }

        else if (currentPValue == 21)
        {
            eventLog.setText("Right on! Black Jack!");
            currentScore++;
            score.setText("SCORE: " + currentScore);
            runningGame = false;
            cardVisualUpdate();
            gameUpdate();
        }

        else if (currentDValue > 21)
        {
            eventLog.setText("The dealer is over! You win!");
            currentScore++;
            score.setText("SCORE: " + currentScore);
            runningGame = false;
            cardVisualUpdate();
            gameUpdate();
        }

        else if (standing && currentPValue > currentDValue)
        {
            eventLog.setText("You win this one!");
            currentScore++;
            score.setText("SCORE: " + currentScore);
            runningGame = false;
            cardVisualUpdate();
            gameUpdate();
        }

        else if (standing && currentPValue < currentDValue && currentDValue < 22)
        {
            eventLog.setText("You lose this one!");
            currentScore--;
            score.setText("SCORE: " + currentScore);
            runningGame = false;
            cardVisualUpdate();
            gameUpdate();
        }

        else if (standing && currentPValue == currentDValue)
        {
            eventLog.setText("Looks to be a draw. Push!");
            runningGame = false;
            cardVisualUpdate();
            gameUpdate();
        }
    }

    int cardMath(int currentCard, int player)
    {
        while (currentCard > 13)
            currentCard -= 13;

        if(currentCard > 1 && currentCard < 11)
            return currentCard;

        else if (currentCard > 10)
            return 10;

        else
        {
            if (player == 1)
                playerAce = true;
            else
                dealerAce = true;

            return 1;
        }
    }

    void dealersTurn()
    {
        while(currentDValue < 17 && currentDCard < 6)
        {
            dealNewCard(0);
            currentDValue += cardMath(dealerCards[currentDCard - 1], 0);
            Log.d("myTag", "Currently in dealer loop");
        }

        checkGame();
    }

    void dealNewCard(int player)
    {
        Random rng = new Random();
        boolean dealt = false;

        while (dealt == false && player == 1)
        {
            playerCards[currentPCard] = rng.nextInt(52) + 1;
            if(theDeck[playerCards[currentPCard] - 1] == 1)
            {
                theDeck[playerCards[currentPCard] - 1] = 0;
                currentPCard++;
                dealt = true;
            }
        }

        while (dealt == false && player == 0)
        {
            dealerCards[currentDCard] = rng.nextInt(52) + 1;
            if(theDeck[dealerCards[currentDCard] - 1] == 1)
            {
                theDeck[dealerCards[currentDCard] - 1] = 0;
                currentDCard++;
                dealt = true;
            }
        }
    }

    void cardVisualUpdate()
    {
        cardsValues[0] = playerCards[0];
        cardsValues[1] = playerCards[1];
        cardsValues[2] = playerCards[2];
        cardsValues[3] = playerCards[3];
        cardsValues[4] = playerCards[4];
        cardsValues[5] = playerCards[5];

        cardsValues[6] = dealerCards[0];
        cardsValues[7] = dealerCards[1];
        cardsValues[8] = dealerCards[2];
        cardsValues[9] = dealerCards[3];
        cardsValues[10]= dealerCards[4];
        cardsValues[11]= dealerCards[5];

        if (!runningGame) {
            for (int i = 0; i < 12; i++) {
                if (cardsValues[i] == 0)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.no_card));

                else if (cardsValues[i] == 1)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_spades));

                else if (cardsValues[i] == 2)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_spades));

                else if (cardsValues[i] == 3)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_spades));

                else if (cardsValues[i] == 4)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_spades));

                else if (cardsValues[i] == 5)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_spades));

                else if (cardsValues[i] == 6)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_spades));

                else if (cardsValues[i] == 7)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_spades));

                else if (cardsValues[i] == 8)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_spades));

                else if (cardsValues[i] == 9)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_spades));

                else if (cardsValues[i] == 10)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_spades));

                else if (cardsValues[i] == 11)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_spades));

                else if (cardsValues[i] == 12)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_spades));

                else if (cardsValues[i] == 13)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_spades));

                else if (cardsValues[i] == 14)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_hearts));

                else if (cardsValues[i] == 15)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_hearts));

                else if (cardsValues[i] == 16)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_hearts));

                else if (cardsValues[i] == 17)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_hearts));

                else if (cardsValues[i] == 18)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_hearts));

                else if (cardsValues[i] == 19)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_hearts));

                else if (cardsValues[i] == 20)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_hearts));

                else if (cardsValues[i] == 21)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_hearts));

                else if (cardsValues[i] == 22)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_hearts));

                else if (cardsValues[i] == 23)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_hearts));

                else if (cardsValues[i] == 24)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_hearts));

                else if (cardsValues[i] == 25)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_hearts));

                else if (cardsValues[i] == 26)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_hearts));

                else if (cardsValues[i] == 27)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_clubs));

                else if (cardsValues[i] == 28)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_clubs));

                else if (cardsValues[i] == 29)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_clubs));

                else if (cardsValues[i] == 30)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_clubs));

                else if (cardsValues[i] == 31)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_clubs));

                else if (cardsValues[i] == 32)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_clubs));

                else if (cardsValues[i] == 33)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_clubs));

                else if (cardsValues[i] == 34)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_clubs));

                else if (cardsValues[i] == 35)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_clubs));

                else if (cardsValues[i] == 36)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_clubs));

                else if (cardsValues[i] == 37)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_clubs));

                else if (cardsValues[i] == 38)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_clubs));

                else if (cardsValues[i] == 39)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_clubs));

                else if (cardsValues[i] == 40)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_diamonds));

                else if (cardsValues[i] == 41)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_diamonds));

                else if (cardsValues[i] == 42)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_diamonds));

                else if (cardsValues[i] == 43)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_diamonds));

                else if (cardsValues[i] == 44)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_diamonds));

                else if (cardsValues[i] == 45)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_diamonds));

                else if (cardsValues[i] == 46)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_diamonds));

                else if (cardsValues[i] == 47)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_diamonds));

                else if (cardsValues[i] == 48)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_diamonds));

                else if (cardsValues[i] == 49)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_diamonds));

                else if (cardsValues[i] == 50)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_diamonds));

                else if (cardsValues[i] == 51)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_diamonds));

                else if (cardsValues[i] == 52)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_diamonds));

                else
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.face_down_card));
            }

            currentPlayer.setText("CURRENT;\n" + currentPValue);
            currentDealer.setText("CURRENT;\n" + currentDValue);
        }

        else
        {
            for (int i = 0; i < 7; i++) {
                if (cardsValues[i] == 0)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.no_card));

                else if (cardsValues[i] == 1)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_spades));

                else if (cardsValues[i] == 2)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_spades));

                else if (cardsValues[i] == 3)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_spades));

                else if (cardsValues[i] == 4)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_spades));

                else if (cardsValues[i] == 5)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_spades));

                else if (cardsValues[i] == 6)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_spades));

                else if (cardsValues[i] == 7)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_spades));

                else if (cardsValues[i] == 8)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_spades));

                else if (cardsValues[i] == 9)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_spades));

                else if (cardsValues[i] == 10)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_spades));

                else if (cardsValues[i] == 11)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_spades));

                else if (cardsValues[i] == 12)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_spades));

                else if (cardsValues[i] == 13)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_spades));

                else if (cardsValues[i] == 14)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_hearts));

                else if (cardsValues[i] == 15)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_hearts));

                else if (cardsValues[i] == 16)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_hearts));

                else if (cardsValues[i] == 17)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_hearts));

                else if (cardsValues[i] == 18)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_hearts));

                else if (cardsValues[i] == 19)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_hearts));

                else if (cardsValues[i] == 20)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_hearts));

                else if (cardsValues[i] == 21)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_hearts));

                else if (cardsValues[i] == 22)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_hearts));

                else if (cardsValues[i] == 23)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_hearts));

                else if (cardsValues[i] == 24)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_hearts));

                else if (cardsValues[i] == 25)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_hearts));

                else if (cardsValues[i] == 26)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_hearts));

                else if (cardsValues[i] == 27)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_clubs));

                else if (cardsValues[i] == 28)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_clubs));

                else if (cardsValues[i] == 29)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_clubs));

                else if (cardsValues[i] == 30)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_clubs));

                else if (cardsValues[i] == 31)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_clubs));

                else if (cardsValues[i] == 32)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_clubs));

                else if (cardsValues[i] == 33)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_clubs));

                else if (cardsValues[i] == 34)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_clubs));

                else if (cardsValues[i] == 35)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_clubs));

                else if (cardsValues[i] == 36)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_clubs));

                else if (cardsValues[i] == 37)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_clubs));

                else if (cardsValues[i] == 38)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_clubs));

                else if (cardsValues[i] == 39)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_clubs));

                else if (cardsValues[i] == 40)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ace_of_diamonds));

                else if (cardsValues[i] == 41)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.two_of_diamonds));

                else if (cardsValues[i] == 42)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.three_of_diamonds));

                else if (cardsValues[i] == 43)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.four_of_diamonds));

                else if (cardsValues[i] == 44)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.five_of_diamonds));

                else if (cardsValues[i] == 45)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.six_of_diamonds));

                else if (cardsValues[i] == 46)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.seven_of_diamonds));

                else if (cardsValues[i] == 47)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.eight_of_diamonds));

                else if (cardsValues[i] == 48)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.nine_of_diamonds));

                else if (cardsValues[i] == 49)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.ten_of_diamonds));

                else if (cardsValues[i] == 50)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.jack_of_diamonds));

                else if (cardsValues[i] == 51)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.queen_of_diamonds));

                else if (cardsValues[i] == 52)
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.king_of_diamonds));

                else
                    cardsDisplay[i].setImageDrawable(getResources().getDrawable(R.drawable.face_down_card));
            }

            cardsDisplay[7].setImageDrawable(getResources().getDrawable(R.drawable.face_down_card));
            cardsDisplay[8].setImageDrawable(getResources().getDrawable(R.drawable.no_card));
            cardsDisplay[9].setImageDrawable(getResources().getDrawable(R.drawable.no_card));
            cardsDisplay[10].setImageDrawable(getResources().getDrawable(R.drawable.no_card));
            cardsDisplay[11].setImageDrawable(getResources().getDrawable(R.drawable.no_card));

            currentPlayer.setText("CURRENT;\n" + currentPValue);
            currentDealer.setText("CURRENT;\n" + (dealerShowValue + 1) + " <");
        }


    }


}
